util.keep_running()
util.require_natives(1640181023)
local scaleform = require("ScaleformLib")
local sf = scaleform("instructional_buttons")
local JSkey = require 'JSkeyLib'

local is_vehicle_flying = false
local dont_stop = false
local no_collision = false
local stop_on_exit = true
local speed = 6
local double_speed = false

local vehicleFlyToggle vehicleFlyToggle = menu.toggle_loop(menu.my_root(), "Vehicle Fly", {"vehfly"}, "I recommend setting a hotkey to this option.", function()
    local veh = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
    VEHICLE.SET_VEHICLE_GRAVITY(veh, false)

    if veh == 0 then
        util.toast("This function is only available when inside a vehicle. :/")
        menu.trigger_command(vehicleFlyToggle, "off")
        return
    end

    local counter = 0
    while not NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(veh) and counter < 100 do
        NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(veh)
        util.yield(5)
    end
    if not NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(veh) and counter >= 100 then
        util.toast("Failed to get control of the vehicle. :/")
        menu.trigger_command(vehicleFlyToggle, "off")
    else
        do_vehicle_fly()
    end
end, function()
    util.create_tick_handler(function()
        VEHICLE.SET_VEHICLE_GRAVITY(veh, true)
        if is_vehicle_flying then
            do_vehicle_fly()
        else
            ENTITY.SET_ENTITY_COLLISION(veh, true, true)
        end
    end)

    VEHICLE.SET_VEHICLE_GRAVITY(veh, true)
    ENTITY.SET_ENTITY_COLLISION(veh, true, true);
    sf:delete()
end)

menu.slider(menu.my_root(), "Speed", {"vflyspeed"}, "", 1, 100, 6, 1, function(on_change)
    speed = on_change
end)
menu.toggle(menu.my_root(), "Don't Stop After Input", {"vflynostop"}, "", function(on_click)
    dont_stop = on_click
end)
menu.toggle(menu.my_root(), "No Collision", {"vflynocollide"}, "", function(on_click)
    no_collision = on_click
end)
menu.toggle(menu.my_root(), "Stop on Exit", {"vflystopexit"}, "", function(on_click)
    stop_on_exit = on_click
end, true)

function do_vehicle_fly()
    veh = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
    cam_pos = CAM.GET_GAMEPLAY_CAM_ROT(0)
    ENTITY.SET_ENTITY_COLLISION(veh, not no_collision, true)
    ENTITY.SET_ENTITY_ROTATION(veh, cam_pos.x, cam_pos.y, cam_pos.z, 1, true)

    HUD.HIDE_HUD_COMPONENT_THIS_FRAME(6)
    HUD.HIDE_HUD_COMPONENT_THIS_FRAME(7)
    HUD.HIDE_HUD_COMPONENT_THIS_FRAME(8)
    HUD.HIDE_HUD_COMPONENT_THIS_FRAME(9)

    memory.write_int(memory.script_global(1645739+1121), 1)
    sf.CLEAR_ALL()
    sf.TOGGLE_MOUSE_BUTTONS(false)
    sf.SET_DATA_SLOT(2, JSkey.get_control_instructional_button(0, 'INPUT_VEH_MOVE_UP_ONLY'  ), 'Up')
    sf.SET_DATA_SLOT(1, JSkey.get_control_instructional_button(0, 'INPUT_VEH_MOVE_DOWN_ONLY'), 'Down')
    sf.SET_DATA_SLOT(0, JSkey.get_control_instructional_button(0, 'INPUT_VEH_HANDBRAKE'     ), 'Toggle Sprint')
    sf.DRAW_INSTRUCTIONAL_BUTTONS()
    sf:draw_fullscreen()

    local localSpeed = speed*10
    if JSkey.is_control_just_pressed(0, 'INPUT_VEH_HANDBRAKE') then
        double_speed = not double_speed
    end

    if double_speed then
        localSpeed = localSpeed*2
    end

    if JSkey.is_control_pressed(2, 'INPUT_VEH_ACCELERATE') then
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0, speed, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1)
        else
            VEHICLE.SET_VEHICLE_FORWARD_SPEED(veh, localSpeed)
        end
	end
    if JSkey.is_control_pressed(2, 'INPUT_VEH_BRAKE') then
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0.0, -speed, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1)
        else
            VEHICLE.SET_VEHICLE_FORWARD_SPEED(veh, -localSpeed)
        end
   end

    if JSkey.is_control_pressed(2, 'INPUT_VEH_MOVE_LEFT_ONLY') then
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, -speed, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1)
        else
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, -localSpeed, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1)
        end
	end
    if JSkey.is_control_pressed(2, 'INPUT_VEH_MOVE_RIGHT_ONLY') then
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, speed, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1)
        else
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, localSpeed, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1)
        end
    end

    if (JSkey.is_control_pressed(2, 'INPUT_VEH_MOVE_UP_ONLY') and not JSkey.is_key_down('VK_NUMPAD8')) or JSkey.is_key_down('VK_SHIFT') then
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0, 0, speed, 0, 0, 0, 0, 1, 1, 1, 0, 1)
        else
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0, 0, localSpeed, 0, 0, 0, 0, 1, 1, 1, 0, 1)
        end
    end
    if (JSkey.is_control_pressed(2, 'INPUT_VEH_MOVE_DOWN_ONLY') and not JSkey.is_key_down('VK_NUMPAD5')) or JSkey.is_key_down('VK_CONTROL') then
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0, 0, -speed, 0, 0, 0, 0, 1, 1, 1, 0, 1)
        else
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0, 0, -localSpeed, 0, 0, 0, 0, 1, 1, 1, 0, 1)
        end
    end

	if not dont_stop and not JSkey.is_control_pressed(2, 'INPUT_VEH_ACCELERATE') and not JSkey.is_control_pressed(2, 'INPUT_VEH_BRAKE') then
        VEHICLE.SET_VEHICLE_FORWARD_SPEED(veh, 0.0)
    end
    if TASK.GET_IS_TASK_ACTIVE(PLAYER.PLAYER_PED_ID(), 2) then
        menu.trigger_command(vehicleFlyToggle, 'off')
        local veh = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), true);
        VEHICLE.SET_VEHICLE_GRAVITY(veh, true)
        ENTITY.SET_ENTITY_COLLISION(veh, true, true)
        if stop_on_exit then
            VEHICLE.SET_VEHICLE_FORWARD_SPEED(veh, 0)
        end
    end
end